

"""
断言常量
"""

class Ac(object):
    """
    设置断言常量
    """
    eq = "self.assertEquals(str({}),'{}')"


